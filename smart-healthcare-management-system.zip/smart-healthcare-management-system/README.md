# Smart Healthcare Management System

An integrated hospital management web application: patient records, doctor profiles and availability,
appointment booking with overlap prevention, diagnostic test tracking, and hospital administration,
with role-based access for **Admin, Doctor, Receptionist and Patient**.

> **All data in this project is fictional.** Demo accounts and sample records are created only on a local,
> empty database. Do not store real patient information in this demo, and do not deploy it with demo data.

## Tech stack

Java 21 · Spring Boot 3.5 · Spring MVC · Spring Data JPA / Hibernate · Spring Security 6 · Thymeleaf ·
MySQL 8 · Bootstrap 5 (CDN) · Maven · JUnit 5 / MockMvc / H2 (tests only)

## Architecture

```
Browser (Thymeleaf pages + Bootstrap)         curl / Postman (JSON, HTTP Basic)
              │                                          │
      web/*Controller  (MVC, forms)              api/ApiController (REST)
              └──────────────┬───────────────────────────┘
                       service/*  (business rules, ownership checks, transactions)
                             │
                      repository/*  (Spring Data JPA, specifications)
                             │
                          MySQL
```

* **Security** – two filter chains: form login + CSRF for the web UI, stateless HTTP Basic for `/api/**`.
  `@PreAuthorize` on controllers *and* ownership checks inside services (a patient can only see their own data,
  a doctor only their own patients/tests).
* **Overlap prevention** – while booking, the doctor row is locked (`SELECT ... FOR UPDATE`), then the service
  checks availability, working hours, past dates, and overlapping appointments for both doctor and patient.

### Folder structure

```
smart-healthcare-management-system/
├── pom.xml
├── run.bat                          # Windows helper (mvn spring-boot:run)
├── README.md  LICENSE  .gitignore  .gitattributes
├── .github/workflows/build.yml      # CI: mvn verify on every push
├── database/
│   ├── 01_create_database.sql       # database + app user
│   └── 02_schema.sql                # optional reference schema (Hibernate creates tables by default)
└── src/
    ├── main/java/com/smarthealth/hms/
    │   ├── HmsApplication.java
    │   ├── config/      SecurityConfig, AppConfig, DataSeeder (fictional demo data)
    │   ├── domain/      User, Patient, Doctor, Department, Staff, Appointment, DiagnosticTest + enums
    │   ├── dto/         validated form objects
    │   ├── repository/  Spring Data repositories + search specifications
    │   ├── service/     User, Patient, Doctor, Department, Staff, Appointment, Diagnostic, Dashboard
    │   ├── security/    AppUserDetails, login lockout
    │   ├── web/         MVC controllers + error handling
    │   ├── api/         REST controller, DTO records, JSON error handler
    │   ├── exception/   ResourceNotFoundException, BusinessRuleException
    │   └── util/        PasswordPolicy, QueryStrings
    ├── main/resources/
    │   ├── application.properties
    │   ├── static/css/app.css, static/js/app.js
    │   └── templates/   layout + form fragments, login, register, error,
    │                    dashboard/, patients/, doctors/, appointments/, diagnostics/, admin/
    └── test/            service tests, MockMvc security tests, unit tests (H2 in memory)
```

### Roles and permissions

| Feature | Admin | Receptionist | Doctor | Patient |
|---|:-:|:-:|:-:|:-:|
| Dashboard (role specific) | ✔ | ✔ | ✔ | ✔ |
| Register / edit patients | ✔ | ✔ | – | self-register |
| View patient records | all | all | own patients | own record |
| Delete patient | ✔ | – | – | – |
| Doctors: view | ✔ | ✔ | ✔ | ✔ |
| Doctors: add / edit / delete | ✔ | – | – | – |
| Book / reschedule appointments | ✔ | ✔ | – | own |
| Cancel appointments | ✔ | ✔ | own | own |
| Complete appointment (notes) | ✔ | – | own | – |
| Request diagnostic test | ✔ | – | own patients | – |
| Update test status | ✔ | ✔ | own tests | – |
| Enter / read results | ✔ | cannot read results | own tests | own, once completed |
| Departments, staff, accounts, schedule | ✔ | – | – | – |

## Run it on Windows (step by step)

### 1. Check / install Java 21

```bat
java -version
```
Should print version 21 (or newer). If not, install **Eclipse Temurin JDK 21** from https://adoptium.net
(tick "Set JAVA_HOME" and "Add to PATH" in the installer), then open a **new** Command Prompt and re-check.

### 2. Check / install Maven

```bat
mvn -version
```
If the command is not found: download the Binary zip from https://maven.apache.org/download.cgi, extract it to
`C:\apache-maven`, then add `C:\apache-maven\bin` to the **Path** environment variable (Start → "Edit the system
environment variables" → Environment Variables → Path → New). Open a new Command Prompt and run `mvn -version`.
It must show Java 21 too; if it shows another Java, set `JAVA_HOME` to your JDK 21 folder.

### 3. Install and configure MySQL

1. Install **MySQL Community Server 8** (https://dev.mysql.com/downloads/installer/) and remember the `root` password.
2. Create the database and a dedicated user. Edit the password inside `database\01_create_database.sql`
   first, then:
   ```bat
   mysql -u root -p < database\01_create_database.sql
   ```
   (If `mysql` is not found, use the "MySQL 8.0 Command Line Client" from the Start menu and paste the SQL.)
   You can also skip this step and use `root`: the app creates the `smart_healthcare` database itself.

### 4. Set environment variables (current Command Prompt only)

```bat
set DB_USERNAME=hms_user
set DB_PASSWORD=ChangeThisPassword#1
```
(use the same user/password you chose in step 3, or `root` and your root password.)
Optional: `set DB_URL=jdbc:mysql://localhost:3306/smart_healthcare?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata`
· `set SERVER_PORT=8081` · `set HMS_DEMO_PASSWORD=YourOwn#Demo1` · `set HMS_SEED_ENABLED=false`.

To make variables permanent, use `setx DB_USERNAME hms_user` (and `setx DB_PASSWORD ...`), then open a new window.

### 5. Run tests and start the app

```bat
cd smart-healthcare-management-system
mvn clean verify
mvn spring-boot:run
```
`mvn verify` runs the automated tests (they use an in-memory H2 database, so MySQL is not needed for them).
On first start Hibernate creates all tables and the seeder adds fictional demo data.

### 6. Open the application

Go to **http://localhost:8080** and sign in.

### Demo logins (local seeded accounts only)

Password for all demo accounts: `Demo@12345` (override with `HMS_DEMO_PASSWORD` before the *first* start).

| Role | Username |
|---|---|
| Admin | `admin` |
| Receptionist | `reception` |
| Doctors | `dr.sharma`, `dr.iyer`, `dr.khan` |
| Patients | `patient1`, `patient2` |

Never use these credentials or `HMS_SEED_ENABLED=true` on a public server.

### Things to try (guided demo)

1. Sign in as `reception` → **Register patient** (tick the optional login) → **Book appointment** → pick a doctor,
   date and a free slot. Try booking the same slot again: the overlap is rejected.
2. Sign in as `dr.sharma` → open an appointment → **Request diagnostic test**, then enter a result (use sample text).
3. Sign in as `patient1` → see appointments, reschedule/cancel, and a completed test result.
4. Sign in as `admin` → Departments, Staff, User Accounts, Daily Schedule and the summary dashboard.

## REST API

HTTP Basic authentication, JSON. Same authorization rules as the web UI. (`^` is the Windows line continuation.)

```bat
:: who am I
curl -u admin:Demo@12345 http://localhost:8080/api/me

:: search patients (admin / receptionist / doctor)
curl -u reception:Demo@12345 "http://localhost:8080/api/patients?q=riya"

:: register a patient (admin / receptionist)
curl -u reception:Demo@12345 -X POST http://localhost:8080/api/patients ^
  -H "Content-Type: application/json" ^
  -d "{\"firstName\":\"Asha\",\"lastName\":\"Demo\",\"gender\":\"FEMALE\",\"dateOfBirth\":\"1993-03-14\",\"phone\":\"9000000555\"}"

:: doctors and free slots
curl -u patient1:Demo@12345 http://localhost:8080/api/doctors
curl -u patient1:Demo@12345 "http://localhost:8080/api/doctors/1/slots?date=2026-11-16"

:: book an appointment (a patient books for themselves; staff must pass patientId)
curl -u patient1:Demo@12345 -X POST http://localhost:8080/api/appointments ^
  -H "Content-Type: application/json" ^
  -d "{\"doctorId\":1,\"appointmentDate\":\"2026-11-16\",\"startTime\":\"11:00\",\"reason\":\"Check-up\"}"

:: reschedule / cancel
curl -u patient1:Demo@12345 -X PUT http://localhost:8080/api/appointments/7/reschedule ^
  -H "Content-Type: application/json" -d "{\"appointmentDate\":\"2026-11-18\",\"startTime\":\"09:30\"}"
curl -u patient1:Demo@12345 -X DELETE http://localhost:8080/api/appointments/7

:: lists
curl -u dr.sharma:Demo@12345 "http://localhost:8080/api/appointments?status=SCHEDULED"
curl -u dr.sharma:Demo@12345 http://localhost:8080/api/diagnostics
curl -u admin:Demo@12345 http://localhost:8080/api/dashboard
```

| Method & path | Who |
|---|---|
| `GET /api/me`, `GET /api/dashboard` | any signed-in user |
| `GET /api/patients`, `GET /api/patients/{id}` | admin, receptionist, doctor (own patients); patient: own id |
| `POST /api/patients` | admin, receptionist |
| `GET /api/doctors`, `GET /api/doctors/{id}/slots?date=` | any signed-in user |
| `GET /api/appointments` | any (filtered by role) |
| `POST /api/appointments`, `PUT /api/appointments/{id}/reschedule` | admin, receptionist, patient |
| `DELETE /api/appointments/{id}` (cancel) | owner roles |
| `GET /api/diagnostics` | any (filtered by role; result text only if allowed) |

Errors are JSON: `{"status":409,"error":"Conflict","message":"..."}`; validation errors add a `fields` object.

## Security notes

* Passwords: BCrypt hashes only; password policy enforced server-side (8–64 chars, letter + digit).
* Login lockout: 5 failed attempts lock the username for 15 minutes (in memory, resets on restart).
* CSRF protection on all web forms; sessions are HttpOnly + SameSite=Lax; logout invalidates the session.
* Content-Security-Policy header; no stack traces or internal messages are ever shown to users.
* Server-side validation on every form (Bean Validation) plus business rules in services.
* No secrets in the repository: DB credentials come from environment variables.

## Uploading to GitHub

```bat
cd smart-healthcare-management-system
git init
git add .
git status
git commit -m "Initial commit: Smart Healthcare Management System"
git branch -M main
git remote add origin https://github.com/<your-username>/smart-healthcare-management-system.git
git push -u origin main
```
Create the empty repository on github.com first (do **not** add a README there). `.gitignore` already excludes
`target/`, IDE files and `.env`. Double-check with `git status` that no password is in any file you commit.
The included GitHub Actions workflow builds and tests the project on every push.

## Troubleshooting

| Problem | Fix |
|---|---|
| `'mvn' is not recognized` | Maven `bin` folder is not in `Path`; open a **new** Command Prompt after changing it. |
| `release version 21 not supported` / wrong Java | `java -version` and `mvn -version` must both show 21+. Fix `JAVA_HOME`. |
| `Access denied for user 'root'@'localhost'` | Wrong `DB_USERNAME` / `DB_PASSWORD`; variables must be set in the same Command Prompt. |
| `Communications link failure` / connection refused | MySQL service not running: `services.msc` → start **MySQL80**. Check port 3306. |
| `Unknown database` / permission to create database | Run `database\01_create_database.sql` as root, or use `root`. |
| `Port 8080 was already in use` | `set SERVER_PORT=8081` and open http://localhost:8081. |
| Login says invalid / locked | Demo password is `Demo@12345`; after 5 wrong tries wait 15 minutes or restart the app. |
| No demo users | Seeding runs only on an empty `users` table and needs `HMS_SEED_ENABLED=true` (default). Drop and recreate the database to reseed. |
| Page has no styling / icons | Bootstrap loads from cdn.jsdelivr.net; check your internet connection. |
| `Schema-validation` / table errors after pulling changes | Use a fresh database, or keep `DDL_AUTO=update` (default). |
| Dependencies fail to download | Check internet / proxy settings in `%USERPROFILE%\.m2\settings.xml`. |

## Known limitations

* Not yet verified in the authoring environment: the project was written without access to Maven Central, so
  `mvn verify` and a live MySQL run must be done on your machine (steps above). If anything fails, the error
  output will point to the exact file; please report it.
* Login lockout and rate limiting are in-memory (single instance only); no e-mail verification or password-reset
  by e-mail; no multi-factor authentication.
* The doctor/patient drop-downs list up to 500 records (no type-ahead search).
* Appointment length is a single global value (`hms.appointment.slot-minutes`, default 30).
* Bootstrap/icons are loaded from a CDN (internet needed in the browser).
* Existing browser sessions stay valid after an account is disabled until they expire.
* Not a certified medical system and not compliant with healthcare regulations (HIPAA, etc.).

## License

MIT – see [LICENSE](LICENSE).
